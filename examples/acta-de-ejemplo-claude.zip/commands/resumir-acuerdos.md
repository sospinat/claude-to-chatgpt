---
description: Resume acuerdos de una reunion en la plantilla adjunta.
---
Organiza $ARGUMENTS siguiendo ${CLAUDE_PLUGIN_ROOT}/assets/plantilla.txt.